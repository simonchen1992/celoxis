Platform
========

Aggregated polyfills the Polymer platform. 
